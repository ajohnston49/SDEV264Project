package com.example.autotracker.ui.theme


object ThemeManager {
    var themeSelector: Int = 1 // Default theme is Car
}

object ColorMode {
    var ColorSelector: Int = 1 //  Default Color is Dark mode
}
//here